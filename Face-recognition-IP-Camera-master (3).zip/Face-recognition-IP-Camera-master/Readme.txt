Add numpy and opencv package
Change ip address
Change video resolution in IP camera app to 352*288 to avoid video lag
