# Facial Recognition System For Hindu Gods
In this project I challenged myself to build a Facial Recognition System with minimal computational resources
and on those subjects which never ever had came under the radar of Facial Recognition System i.e. Gods,to be more precise Hindu Gods. 

[you tube video link to view the project video](https://youtu.be/F8rtvdLBTiA)


[For step by step approach do visit my article published under towards data science](https://towardsdatascience.com/when-computer-vision-meets-hindu-gods-927b5fa22063)
